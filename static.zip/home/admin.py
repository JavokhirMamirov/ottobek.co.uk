from django.contrib import admin
from home.models import *
# Register your models here.
admin.site.register(HomeBarner)
admin.site.register(AboutUs)
admin.site.register(AboutUsItem)
admin.site.register(FAQ)
admin.site.register(FAQItem)
admin.site.register(Service)
admin.site.register(Project)
admin.site.register(ProjectItem)
admin.site.register(Contact)
admin.site.register(Footer)

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_name', 'email', 'phone', 'date', 'unread']